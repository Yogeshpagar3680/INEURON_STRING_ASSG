package question4;

import java.util.Locale;

/**
 * WAP to check if the String is a Pangram or not.
 */
public class Alien4 {

    public void containsAllLetters(String str)
    {
        //Converting the given string into lowercase
        str = str.toLowerCase();

        boolean allLetterPresent = true;

        // Loop over each character itself
        for(char ch = 'a'; ch <= 'z'; ch++)
        {
            //check if the string does not contains all the letters
            if(!str.contains(String.valueOf(ch)))
            {
                allLetterPresent = false;
                break;
            }
        }
        if(allLetterPresent)
            System.out.println(str + " is Pangram");
        else
            System.out.println(str + " is not Pangram");
    }
}
class LaunchAlien4{
    public static void main(String[] args) {

        Alien4 alien4 = new Alien4();

        alien4.containsAllLetters("Abcdefghijklmnopqrstuvwxyz");
        alien4.containsAllLetters("Yogesh");
    }
}
