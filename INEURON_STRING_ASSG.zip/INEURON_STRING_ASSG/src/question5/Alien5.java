package question5;

import java.util.Arrays;

/**
 * WAP to print repeatedly occurring characters in the given String.
 */
public class Alien5 {

    public void printDuplicates(String str)
    {
        int length = str.length();

        char[] chars = str.toCharArray();
        Arrays.sort(chars);
        String sortedStr = new String(chars);

        for(int i=0; i<=length; i++)
        {
            int count = 1;

            while (i < length-1 && sortedStr.charAt(i) == sortedStr.charAt(i+1))
            {
                count++;
                i++;
            }
            if (count > 1) {
                System.out.println(sortedStr.charAt(i)
                        + ", count = " + count);
            }
        }
    }
}
class LaunchAlien5{
    public static void main(String[] args) {

        Alien5 alien5 = new Alien5();

        String str = "test string";
        alien5.printDuplicates(str);

        System.out.println("--------------------");

        String str1 = "RAMAYANA";
        alien5.printDuplicates(str1);
    }
}
