package question3;

import java.util.Arrays;

/**
 * WAP to check if the String is Anagram or not.
 */
public class Alien3 {

    public void areAnagram(String str1, String str2)
    {
        //Get length of both strings
        int n1 = str1.length();
        int n2 = str2.length();

        boolean status = true;

        //if length of both strings are not equal then they can't be anagram
        if(n1 != n2) {
            status = false;
        }
        else {
            char[] arrayS1 = str1.toLowerCase().toCharArray();
            char[] arrayS2 = str2.toLowerCase().toCharArray();

            //sort both strings
            Arrays.sort(arrayS1);
            Arrays.sort(arrayS2);

            //compare sorted strings
            status = Arrays.equals(arrayS1, arrayS2);
        }
        if(status)
            System.out.println(str1 + " and " + str2 + " are anagrams");
        else
            System.out.println(str1 + " and " + str2 + " are not anagrams");
    }
}
class Main{
    public static void main(String[] args) {

        Alien3 alien3 = new Alien3();

        alien3.areAnagram("Keep","Peek");
        alien3.areAnagram("Mother In Law", "Hitler Woman");
    }
}
