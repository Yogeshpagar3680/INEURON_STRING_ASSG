package question7;

/**
 * WAP to count the number of Vowels and Consonants of a String value.
 */
public class Alien7 {

    public void count(String str)
    {
        int vowelsCount = 0;
        int consonantsCount = 0;

        str = str.toLowerCase();

        for(int i=0; i<str.length(); i++)
        {
            if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u')
            {
                vowelsCount++;
            }
            else if(str.charAt(i) >= 'a' && str.charAt(i)<='z')
            {
                consonantsCount++;
            }
        }
        System.out.println("Number of vowels :: " + vowelsCount);
        System.out.println("Number of consonants :: " + consonantsCount);
    }
}
class LaunchAlien7{
    public static void main(String[] args) {

        Alien7 alien7 = new Alien7();

        String str1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        alien7.count(str1);

        System.out.println("____________________________________");

        String str2 = "Yogesh Pagar";
        alien7.count(str2);
    }
}