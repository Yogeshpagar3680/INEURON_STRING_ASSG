package question2;

import java.util.Locale;

/**
 * WAP to reverse a sentence while preserving the position.
 * Input : “Think Twice”
 * Output : “kniht eciwt”
 */
public class Alien2 {
    public static void main(String[] args) {

      String s1 = "Think Twice";
      StringBuffer sb = new StringBuffer(" ");
      s1 = s1.toLowerCase();
      String[] words = s1.split(" ");

        for(String word : words){
            for(int i=word.length()-1; i>=0; i--)
            {
                sb = sb.append(word.charAt(i));
            }
        }
        for(int i=0; i<s1.length(); i++){
            if(s1.charAt(i) == ' ')
            {
                sb.insert(i+1," ");
            }
        }
        sb.append(" ");
        System.out.println(sb);
    }
}
